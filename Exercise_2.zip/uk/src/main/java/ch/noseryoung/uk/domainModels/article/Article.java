package ch.noseryoung.uk.domainModels.article;

public class Article {

    /*
        TODO, create the entity "Article".
        This entity should possess the following attributes:
            - id
            - name
            - description
            - value

        Keep in mind that there are no foreign keys in this list of attributes.
        Study the diagram and figure out if there needs to be foreign keys here or not.
    */

}
