package ch.noseryoung.uk.domainModels.article;

public class Article {

    /*
        TODO, create the entity "Article".
        This entity should possess the following attributes:
            - id
            - name
            - description
            - value
    */

}
