package ch.noseryoung.uk.domainModels.article;

public class ArticleController {

    // TODO, create CRUD endpoints for the object "Article"

}
