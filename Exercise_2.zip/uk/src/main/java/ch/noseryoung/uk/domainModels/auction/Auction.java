package ch.noseryoung.uk.domainModels.auction;

public class Auction {

    /*
        TODO, create the entity "Auction".
        This entity should possess the following attributes:
            - id
            - description
            - fixedPrice
            - startingPrice
            - isPublic
    */

}
