package ch.noseryoung.uk.domainModels.auction;

public class Auction {

    /*
        TODO, create the entity "Auction".
        This entity should possess the following attributes:
            - id
            - description
            - fixedPrice
            - startingPrice
            - isPublic

        Keep in mind that there are no foreign keys in this list of attributes.
        Study the diagram and figure out if there needs to be foreign keys here or not.
    */

}
