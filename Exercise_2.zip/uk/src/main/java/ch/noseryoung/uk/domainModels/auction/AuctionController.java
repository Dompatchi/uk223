package ch.noseryoung.uk.domainModels.auction;

public class AuctionController {

    // TODO, create CRUD endpoints for the object "Auction"

}
