package ch.noseryoung.uk.domainModels.authority;

public class Authority {

    /*
        TODO, create the entity "Authority".
        This entity should possess the following attributes:
            - id
            - name
    */

}
