package ch.noseryoung.uk.domainModels.bid;

public class Bid {

    /*
        TODO, create the entity "Bid".
        This entity should possess the following attributes:
            - id
            - amount

        Keep in mind that there are no foreign keys in this list of attributes.
        Study the diagram and figure out if there needs to be foreign keys here or not.
    */

}
