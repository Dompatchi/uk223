package ch.noseryoung.uk.domainModels.bid;

public class Bid {

    /*
        TODO, create the entity "Bid".
        This entity should possess the following attributes:
            - id
            - amount
    */

}
