package ch.noseryoung.uk.domainModels.bid;

public class BidController {

    // TODO, create CRUD endpoints for the object "Bid"

}
