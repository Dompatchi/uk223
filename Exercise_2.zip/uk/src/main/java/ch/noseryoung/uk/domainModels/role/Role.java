package ch.noseryoung.uk.domainModels.role;

public class Role {

    /*
        TODO, create the entity "Role".
        This entity should possess the following attributes:
            - id
            - name

        Keep in mind that there are no foreign keys in this list of attributes.
        Study the diagram and figure out if there needs to be foreign keys here or not.
    */

}
