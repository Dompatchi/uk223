package ch.noseryoung.uk.domainModels.role;

public class Role {

    /*
        TODO, create the entity "Role".
        This entity should possess the following attributes:
            - id
            - name
    */

}
