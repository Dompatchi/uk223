package ch.noseryoung.uk.domainModels.user;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    // This is an example controller with CRUD logic

    private static final List<User> USERS = Arrays.asList();
    private static final User USER = new User();

    @GetMapping({"/", ""})
    public ResponseEntity<List<User>> getAll() {
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getById(@PathVariable String id) {
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @PostMapping({"/", ""})
    public ResponseEntity<User> create(@RequestBody @Valid User user) {
        return new ResponseEntity<>(null, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateById(@PathVariable String id, @RequestBody @Valid User user) {
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable String id) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
