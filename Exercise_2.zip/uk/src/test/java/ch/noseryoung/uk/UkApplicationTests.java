package ch.noseryoung.uk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UkApplicationTests {

	@Test
	void contextLoads() {
	}

}
